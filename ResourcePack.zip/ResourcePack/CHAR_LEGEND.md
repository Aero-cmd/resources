# Character legend

These are the characters this pack adds to Minecraft's default font.
Use them in DeluxeMenus `menu_title` fields with MiniMessage/legacy shift codes,
exactly like the original Oraxen template did — just with these characters instead.

## GUI backgrounds (chest inventory sizes)

| Size (slots) | Character |
|---|---|
| 54 | `\uE050` |
| 45 | `\uE051` |
| 36 | `\uE052` |
| 27 | `\uE053` |
| 18 | `\uE054` |
| 9  | `\uE055` |

## Shift spacers (invisible, used to nudge the background left/right)

| Pixels | Character |
|---|---|
| +1    | `\uE001` |
| +0    | `\uE002` |
| +2    | `\uE003` |
| +6    | `\uE004` |
| +14   | `\uE005` |
| +30   | `\uE006` |
| +62   | `\uE007` |
| +126  | `\uE008` |
| +254  | `\uE009` |
| +510  | `\uE00A` |
| +1022 | `\uE00B` |
| -3    | `\uE00C` |
| -4    | `\uE00D` |
| -6    | `\uE00E` |
| -10   | `\uE00F` |
| -18   | `\uE010` |
| -34   | `\uE011` |
| -66   | `\uE012` |
| -130  | `\uE013` |
| -258  | `\uE014` |
| -514  | `\uE015` |
| -1026 | `\uE016` |

## Example DeluxeMenus menu_title (54-slot GUI, shifted -22px like the original template)

```yaml
menu_title: '&f<shift:-22>\uE050'
```

If your DeluxeMenus version doesn't support the `<shift:-N>` MiniMessage tag, chain the
shift characters directly instead, same as the original Oraxen glyph pack did, e.g.
combine \uE00C/\uE00E/etc. to build up the exact negative offset you need.
